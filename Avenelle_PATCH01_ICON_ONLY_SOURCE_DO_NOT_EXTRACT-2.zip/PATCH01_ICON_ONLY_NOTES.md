# Avenelle Patch 01 — Icon Only

Purpose: replace the Android launcher icon only, while preserving the current working Avenelle foundation.

Protected boundary:
- No feature changes
- No tracking logic changes
- No UI rebuild
- No navigation changes
- No public internal wording added

Verification required:
The GitHub workflow must inspect the built APK and fail if the launcher icon inside the APK still differs from the Avenelle icon patch.
