# Avenelle V5 Surgical Patch Source

This source preserves the working Avenelle app foundation and applies only V5 surgical polish for the Android build path:

- Keeps existing screens and local data logic intact.
- Keeps Avenelle version `5.0.0+50` from `pubspec.yaml`.
- Adds premium Avenelle Android launcher icon resources for the GitHub workflow to inject after Android shell regeneration.
- Does not add features or rebuild the app.

Build with the matching phone-safe workflow file: `.github/workflows/build-apk.yml`.
