import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final repo = CycleRepository();
  await repo.load();
  runApp(AvenelleApp(repository: repo));
}

class AvenelleApp extends StatelessWidget {
  const AvenelleApp({super.key, required this.repository});
  final CycleRepository repository;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: repository,
      builder: (context, _) {
        return MaterialApp(
          title: 'Avenelle',
          debugShowCheckedModeBanner: false,
          theme: AppTheme.theme,
          home: repository.data.onboardingCompleted
              ? AppLockGate(repository: repository)
              : OnboardingScreen(repository: repository),
        );
      },
    );
  }
}

class AppTheme {
  static const cream = Color(0xFFFFF8F1);
  static const blush = Color(0xFFF4C7C3);
  static const lavender = Color(0xFFD9C7EF);
  static const plum = Color(0xFF5A2D55);
  static const charcoal = Color(0xFF322A30);
  static const card = Color(0xFFFFFCF8);
  static const softLine = Color(0xFFE9DAD3);

  static ThemeData get theme {
    return ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: plum,
        surface: cream,
        primary: plum,
        secondary: blush,
      ),
      scaffoldBackgroundColor: cream,
      textTheme: const TextTheme(
        headlineLarge: TextStyle(fontSize: 31, fontWeight: FontWeight.w900, color: charcoal, letterSpacing: -.4),
        headlineMedium: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: charcoal, letterSpacing: -.2),
        titleLarge: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: charcoal),
        titleMedium: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: charcoal),
        bodyLarge: TextStyle(fontSize: 16, height: 1.35, color: charcoal),
        bodyMedium: TextStyle(fontSize: 14, height: 1.35, color: charcoal),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: cream,
        foregroundColor: charcoal,
        elevation: 0,
        centerTitle: false,
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: plum,
        contentTextStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: card,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: softLine)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: softLine)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: plum, width: 1.4)),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: card,
        selectedColor: lavender.withOpacity(.70),
        side: const BorderSide(color: softLine),
        labelStyle: const TextStyle(color: charcoal, fontWeight: FontWeight.w600),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        selectedItemColor: plum,
        unselectedItemColor: Color(0xFF8A7F86),
        backgroundColor: card,
        type: BottomNavigationBarType.fixed,
        selectedLabelStyle: TextStyle(fontWeight: FontWeight.w800, fontSize: 12),
        unselectedLabelStyle: TextStyle(fontWeight: FontWeight.w600, fontSize: 11),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        color: card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: plum,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          minimumSize: const Size.fromHeight(54),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: plum,
          side: const BorderSide(color: plum),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          minimumSize: const Size.fromHeight(54),
        ),
      ),
    );
  }
}

class AppMeta {
  static const versionName = '5.0.0';
  static const versionLabel = 'Avenelle';
}

class SafetyCopy {
  static const signalWindowDisclaimer =
      'Avenelle does not diagnose PMDD or any condition. It organizes your logged patterns so you can prepare earlier or discuss them with a clinician.';
  static const doctorSummaryDisclaimer =
      'This summary organizes your logged data. It does not diagnose any condition.';
  static const latePeriodDisclaimer =
      'Cycle changes can happen for many reasons. Avenelle can help you track your logs, but it does not diagnose causes.';
  static const forbiddenClaims = [
    'you have PMDD',
    'this proves PMDD',
    'treatment plan',
    'clinically confirmed',
    'guaranteed',
    'abnormal',
    'your hormones caused this',
    'medically certain',
  ];
}

class AppData {
  AppData({
    required this.onboardingCompleted,
    required this.lastPeriodStart,
    required this.averagePeriodLength,
    required this.cycleRegularity,
    required this.signalWindowEnabled,
    required this.privateNotifications,
    required this.appLockEnabled,
    required this.pinCode,
    required this.periodLogs,
    required this.symptomLogs,
    required this.flowLogs,
    required this.predictionFeedback,
  });

  bool onboardingCompleted;
  DateTime? lastPeriodStart;
  int averagePeriodLength;
  String cycleRegularity;
  bool signalWindowEnabled;
  bool privateNotifications;
  bool appLockEnabled;
  String? pinCode;
  List<PeriodLog> periodLogs;
  List<SymptomLog> symptomLogs;
  List<FlowLog> flowLogs;
  List<PredictionFeedback> predictionFeedback;

  factory AppData.empty() => AppData(
        onboardingCompleted: false,
        lastPeriodStart: null,
        averagePeriodLength: 5,
        cycleRegularity: 'somewhat_regular',
        signalWindowEnabled: true,
        privateNotifications: true,
        appLockEnabled: false,
        pinCode: null,
        periodLogs: [],
        symptomLogs: [],
        flowLogs: [],
        predictionFeedback: [],
      );

  Map<String, dynamic> toJson() => {
        'onboardingCompleted': onboardingCompleted,
        'lastPeriodStart': lastPeriodStart?.toIso8601String(),
        'averagePeriodLength': averagePeriodLength,
        'cycleRegularity': cycleRegularity,
        'signalWindowEnabled': signalWindowEnabled,
        'privateNotifications': privateNotifications,
        'appLockEnabled': appLockEnabled,
        'pinCode': pinCode,
        'periodLogs': periodLogs.map((e) => e.toJson()).toList(),
        'symptomLogs': symptomLogs.map((e) => e.toJson()).toList(),
        'flowLogs': flowLogs.map((e) => e.toJson()).toList(),
        'predictionFeedback': predictionFeedback.map((e) => e.toJson()).toList(),
      };

  factory AppData.fromJson(Map<String, dynamic> json) => AppData(
        onboardingCompleted: json['onboardingCompleted'] == true,
        lastPeriodStart: json['lastPeriodStart'] == null ? null : DateTime.parse(json['lastPeriodStart']),
        averagePeriodLength: json['averagePeriodLength'] ?? 5,
        cycleRegularity: json['cycleRegularity'] ?? 'somewhat_regular',
        signalWindowEnabled: json['signalWindowEnabled'] ?? true,
        privateNotifications: json['privateNotifications'] ?? true,
        appLockEnabled: json['appLockEnabled'] ?? false,
        pinCode: json['pinCode'],
        periodLogs: ((json['periodLogs'] ?? []) as List).map((e) => PeriodLog.fromJson(e)).toList(),
        symptomLogs: ((json['symptomLogs'] ?? []) as List).map((e) => SymptomLog.fromJson(e)).toList(),
        flowLogs: ((json['flowLogs'] ?? []) as List).map((e) => FlowLog.fromJson(e)).toList(),
        predictionFeedback: ((json['predictionFeedback'] ?? []) as List).map((e) => PredictionFeedback.fromJson(e)).toList(),
      );
}

class PeriodLog {
  PeriodLog({required this.id, required this.startDate, this.endDate, this.excludedFromPrediction = false});
  final String id;
  final DateTime startDate;
  DateTime? endDate;
  bool excludedFromPrediction;

  int get length => endDate == null ? 1 : endDate!.difference(startDate).inDays + 1;

  Map<String, dynamic> toJson() => {
        'id': id,
        'startDate': startDate.toIso8601String(),
        'endDate': endDate?.toIso8601String(),
        'excludedFromPrediction': excludedFromPrediction,
      };

  factory PeriodLog.fromJson(Map<String, dynamic> json) => PeriodLog(
        id: json['id'],
        startDate: DateTime.parse(json['startDate']),
        endDate: json['endDate'] == null ? null : DateTime.parse(json['endDate']),
        excludedFromPrediction: json['excludedFromPrediction'] == true,
      );
}

class SymptomLog {
  SymptomLog({
    required this.id,
    required this.date,
    required this.category,
    required this.name,
    required this.severity,
    required this.lifeImpact,
    this.improvedAfterPeriod,
    this.note,
  });
  final String id;
  final DateTime date;
  final String category;
  final String name;
  final String severity;
  final String lifeImpact;
  final String? improvedAfterPeriod;
  final String? note;

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date.toIso8601String(),
        'category': category,
        'name': name,
        'severity': severity,
        'lifeImpact': lifeImpact,
        'improvedAfterPeriod': improvedAfterPeriod,
        'note': note,
      };

  factory SymptomLog.fromJson(Map<String, dynamic> json) => SymptomLog(
        id: json['id'],
        date: DateTime.parse(json['date']),
        category: json['category'],
        name: json['name'],
        severity: json['severity'],
        lifeImpact: json['lifeImpact'],
        improvedAfterPeriod: json['improvedAfterPeriod'],
        note: json['note'],
      );
}

class FlowLog {
  FlowLog({required this.id, required this.date, required this.flowLevel});
  final String id;
  final DateTime date;
  final String flowLevel;

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date.toIso8601String(),
        'flowLevel': flowLevel,
      };

  factory FlowLog.fromJson(Map<String, dynamic> json) => FlowLog(
        id: json['id'],
        date: DateTime.parse(json['date']),
        flowLevel: json['flowLevel'],
      );
}

class PredictionFeedback {
  PredictionFeedback({required this.date, required this.result, required this.daysOff});
  final DateTime date;
  final String result;
  final int daysOff;

  Map<String, dynamic> toJson() => {
        'date': date.toIso8601String(),
        'result': result,
        'daysOff': daysOff,
      };

  factory PredictionFeedback.fromJson(Map<String, dynamic> json) => PredictionFeedback(
        date: DateTime.parse(json['date']),
        result: json['result'],
        daysOff: json['daysOff'] ?? 0,
      );
}

class PredictionResult {
  PredictionResult({
    required this.mostLikelyDate,
    required this.windowStart,
    required this.windowEnd,
    required this.confidence,
    required this.recentTrend,
    required this.why,
    required this.usualRangeLabel,
  });

  final DateTime mostLikelyDate;
  final DateTime windowStart;
  final DateTime windowEnd;
  final String confidence;
  final String recentTrend;
  final List<String> why;
  final String usualRangeLabel;
}

class CycleRepository extends ChangeNotifier {
  static const _key = 'avenelle_v2_data';
  AppData data = AppData.empty();

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) {
      data = AppData.empty();
      return;
    }
    data = AppData.fromJson(jsonDecode(raw));
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(data.toJson()));
    notifyListeners();
  }

  Future<void> completeOnboarding(DateTime lastStart, int periodLength, List<DateTime> previousDates, bool signalWindow, bool privateNotifications) async {
    final dates = [...previousDates, lastStart]..sort((a, b) => a.compareTo(b));
    data.periodLogs = dates.map((d) => PeriodLog(id: _id(), startDate: d, endDate: d.add(Duration(days: periodLength - 1)))).toList();
    data.lastPeriodStart = lastStart;
    data.averagePeriodLength = periodLength;
    data.signalWindowEnabled = signalWindow;
    data.privateNotifications = privateNotifications;
    data.onboardingCompleted = true;
    await save();
  }

  Future<void> _seedUsefulDemoIfNeeded() async {
    if (data.periodLogs.length >= 3) return;
    final base = data.lastPeriodStart ?? DateTime.now().subtract(const Duration(days: 28));
    final starts = [34, 66, 97].map((days) => base.subtract(Duration(days: days))).toList();
    data.periodLogs.addAll(starts.map((d) => PeriodLog(id: _id(), startDate: d, endDate: d.add(Duration(days: data.averagePeriodLength - 1)))));
    data.periodLogs.sort((a, b) => a.startDate.compareTo(b.startDate));
    data.symptomLogs.addAll([
      SymptomLog(id: _id(), date: base.subtract(const Duration(days: 6)), category: 'mood', name: 'Irritated', severity: 'severe', lifeImpact: 'hard day', improvedAfterPeriod: 'yes'),
      SymptomLog(id: _id(), date: base.subtract(const Duration(days: 7)), category: 'mood', name: 'Anxious', severity: 'severe', lifeImpact: 'conflict', improvedAfterPeriod: 'yes'),
      SymptomLog(id: _id(), date: base.subtract(const Duration(days: 32 + 6)), category: 'mood', name: 'Irritated', severity: 'severe', lifeImpact: 'hard day', improvedAfterPeriod: 'yes'),
      SymptomLog(id: _id(), date: base.subtract(const Duration(days: 64 + 7)), category: 'mood', name: 'Anxious', severity: 'severe', lifeImpact: 'hard day', improvedAfterPeriod: 'yes'),
      SymptomLog(id: _id(), date: base.add(const Duration(days: 26)), category: 'pain', name: 'Cramps', severity: 'moderate', lifeImpact: 'normal day'),
    ]);
    for (final period in data.periodLogs.take(3)) {
      data.flowLogs.add(FlowLog(id: _id(), date: period.startDate.add(const Duration(days: 1)), flowLevel: 'heavy'));
    }
  }

  Future<String> startPeriod(DateTime date, {bool saveAnyway = false}) async {
    final d = _dateOnly(date);
    final existingToday = data.periodLogs.any((log) => sameDay(log.startDate, d));
    if (existingToday) {
      data.lastPeriodStart = d;
      await save();
      return 'Period start already logged for today.';
    }

    final previousStarts = [...data.periodLogs]..sort((a, b) => a.startDate.compareTo(b.startDate));
    if (previousStarts.isNotEmpty) {
      final last = previousStarts.last.startDate;
      final gap = d.difference(last).inDays.abs();
      if (gap > 0 && gap < 15 && !saveAnyway) {
        return 'This is close to your last logged period. Review before saving as a new period start.';
      }
    }

    data.periodLogs.add(PeriodLog(id: _id(), startDate: d, excludedFromPrediction: saveAnyway));
    data.periodLogs.sort((a, b) => a.startDate.compareTo(b.startDate));
    data.lastPeriodStart = d;
    await save();
    return 'Period started for today.';
  }

  Future<void> endLatestPeriod(DateTime date) async {
    if (data.periodLogs.isEmpty) return;
    final d = _dateOnly(date);
    data.periodLogs.sort((a, b) => a.startDate.compareTo(b.startDate));
    data.periodLogs.last.endDate = d;
    await save();
  }

  Future<void> updatePeriodLog(String id, {DateTime? startDate, DateTime? endDate, bool? excludedFromPrediction}) async {
    final index = data.periodLogs.indexWhere((log) => log.id == id);
    if (index == -1) return;
    final log = data.periodLogs[index];
    data.periodLogs[index] = PeriodLog(
      id: log.id,
      startDate: startDate == null ? log.startDate : _dateOnly(startDate),
      endDate: endDate == null ? log.endDate : _dateOnly(endDate),
      excludedFromPrediction: excludedFromPrediction ?? log.excludedFromPrediction,
    );
    data.periodLogs.sort((a, b) => a.startDate.compareTo(b.startDate));
    data.lastPeriodStart = data.periodLogs.isEmpty ? null : data.periodLogs.last.startDate;
    await save();
  }

  Future<void> deletePeriodLog(String id) async {
    data.periodLogs.removeWhere((log) => log.id == id);
    data.periodLogs.sort((a, b) => a.startDate.compareTo(b.startDate));
    data.lastPeriodStart = data.periodLogs.isEmpty ? null : data.periodLogs.last.startDate;
    await save();
  }

  Future<void> addFlow(String flowLevel, {DateTime? date}) async {
    final d = _dateOnly(date ?? DateTime.now());
    data.flowLogs.removeWhere((f) => sameDay(f.date, d));
    data.flowLogs.add(FlowLog(id: _id(), date: d, flowLevel: flowLevel));
    await save();
  }

  Future<void> addSymptom(String category, String name, String severity, String lifeImpact, {DateTime? date, String? improvedAfterPeriod, String? note}) async {
    final d = _dateOnly(date ?? DateTime.now());
    if (category == 'mood') {
      data.symptomLogs.removeWhere((s) => sameDay(s.date, d) && s.category == 'mood');
    } else {
      data.symptomLogs.removeWhere((s) => sameDay(s.date, d) && s.category == category && s.name == name);
    }
    data.symptomLogs.add(SymptomLog(
      id: _id(),
      date: d,
      category: category,
      name: name,
      severity: severity,
      lifeImpact: lifeImpact,
      improvedAfterPeriod: improvedAfterPeriod,
      note: note,
    ));
    await save();
  }


  Future<void> clearFlow({DateTime? date}) async {
    final d = _dateOnly(date ?? DateTime.now());
    data.flowLogs.removeWhere((f) => sameDay(f.date, d));
    await save();
  }

  Future<void> removeSymptom(String category, String name, {DateTime? date}) async {
    final d = _dateOnly(date ?? DateTime.now());
    data.symptomLogs.removeWhere((s) => sameDay(s.date, d) && s.category == category && s.name == name);
    await save();
  }

  Future<void> clearMood({DateTime? date}) async {
    final d = _dateOnly(date ?? DateTime.now());
    data.symptomLogs.removeWhere((s) => sameDay(s.date, d) && s.category == 'mood');
    await save();
  }

  Future<void> deleteLogsForDay(DateTime date) async {
    final d = _dateOnly(date);
    data.flowLogs.removeWhere((f) => sameDay(f.date, d));
    data.symptomLogs.removeWhere((s) => sameDay(s.date, d));
    for (final log in data.periodLogs) {
      if (log.endDate != null && sameDay(log.endDate!, d) && !sameDay(log.startDate, d)) {
        log.endDate = null;
      }
    }
    data.periodLogs.removeWhere((log) => sameDay(log.startDate, d) && (log.endDate == null || sameDay(log.endDate!, d)));
    data.periodLogs.sort((a, b) => a.startDate.compareTo(b.startDate));
    data.lastPeriodStart = data.periodLogs.isEmpty ? null : data.periodLogs.last.startDate;
    await save();
  }

  Future<void> addFeedback(String result, int daysOff) async {
    data.predictionFeedback.add(PredictionFeedback(date: DateTime.now(), result: result, daysOff: daysOff));
    await save();
  }

  Future<void> setPrivacy({bool? privateNotifications, bool? appLockEnabled, String? pinCode}) async {
    if (privateNotifications != null) data.privateNotifications = privateNotifications;
    if (appLockEnabled != null) data.appLockEnabled = appLockEnabled;
    if (pinCode != null) data.pinCode = pinCode;
    if (appLockEnabled == false) data.pinCode = null;
    await save();
  }

  Future<void> deleteAllData() async {
    data = AppData.empty();
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
    notifyListeners();
  }

  PredictionResult get prediction => PredictionEngine.generate(data);
  SignalWindowResult get signalWindow => SignalWindowEngine.detect(data);
  String get doctorSummary => DoctorSummaryEngine.generate(data, prediction, signalWindow);

  FlowLog? flowFor(DateTime date) {
    final d = _dateOnly(date);
    final matches = data.flowLogs.where((f) => sameDay(f.date, d)).toList();
    return matches.isEmpty ? null : matches.last;
  }

  List<SymptomLog> symptomsFor(DateTime date, {String? category}) {
    final d = _dateOnly(date);
    return data.symptomLogs
        .where((s) => sameDay(s.date, d) && (category == null || s.category == category))
        .toList();
  }

  bool periodCovers(DateTime date) {
    final d = _dateOnly(date);
    return data.periodLogs.any((log) => !d.isBefore(log.startDate) && !d.isAfter(log.endDate ?? log.startDate));
  }

  static String _id() => DateTime.now().microsecondsSinceEpoch.toString() + Random().nextInt(9999).toString();
  static DateTime _dateOnly(DateTime date) => DateTime(date.year, date.month, date.day);
}

class PredictionEngine {
  static const int minValidCycleLength = 15;
  static const int maxValidCycleLength = 60;

  static List<int> validCycleLengths(AppData data) {
    final periods = [...data.periodLogs]..sort((a, b) => a.startDate.compareTo(b.startDate));
    final values = <int>[];
    for (var i = 1; i < periods.length; i++) {
      if (periods[i].excludedFromPrediction || periods[i - 1].excludedFromPrediction) continue;
      final len = periods[i].startDate.difference(periods[i - 1].startDate).inDays;
      if (len >= minValidCycleLength && len <= maxValidCycleLength) values.add(len);
    }
    return values;
  }

  static PredictionResult generate(AppData data) {
    final periods = [...data.periodLogs]..sort((a, b) => a.startDate.compareTo(b.startDate));
    final now = DateTime.now();
    if (periods.isEmpty) {
      final likely = now.add(const Duration(days: 28));
      return PredictionResult(
        mostLikelyDate: likely,
        windowStart: likely.subtract(const Duration(days: 7)),
        windowEnd: likely.add(const Duration(days: 7)),
        confidence: 'Low',
        recentTrend: 'Not enough data yet',
        why: ['Avenelle needs your period history before it can narrow your prediction window.'],
        usualRangeLabel: 'Not enough logged cycles yet. Avenelle will calculate this after you log at least 2 period starts.',
      );
    }

    final cycleLengths = validCycleLengths(data);
    final fallback = data.cycleRegularity == 'regular' ? 28 : 32;
    final hasEnoughValidCycles = cycleLengths.length >= 2;
    final weightedAvg = hasEnoughValidCycles ? _weightedAverage(cycleLengths).toDouble() : fallback.toDouble();
    final last = periods.last.startDate;
    final likely = last.add(Duration(days: weightedAvg.round()));
    final variation = hasEnoughValidCycles ? _variation(cycleLengths) : 0;
    final confidence = hasEnoughValidCycles ? _confidence(cycleLengths.length, variation, data.cycleRegularity) : 'Low';
    final width = confidence == 'High' ? 2 : confidence == 'Medium' ? 4 : 7;
    final trend = cycleLengths.length >= 3 ? _trend(cycleLengths) : 'Not enough data yet';
    final cramps = _hasRepeatedSymptom(data, 'Cramps') ? 'You often log cramps near the days before your period.' : null;
    final why = <String>[
      if (hasEnoughValidCycles) 'Your recent valid cycles average ${weightedAvg.round()} days.',
      if (hasEnoughValidCycles) 'Your valid cycles usually vary by about $variation days.',
      if (!hasEnoughValidCycles) 'This prediction starts from your last logged period and will improve with more history.',
      if (trend != 'Not enough data yet') 'Your recent trend is $trend.',
      if (cramps != null) cramps,
      if (data.predictionFeedback.isNotEmpty) 'Your past prediction feedback is used to keep future windows honest.',
    ];
    final usual = hasEnoughValidCycles
        ? 'Your usual logged range is ${cycleLengths.reduce(min)}–${cycleLengths.reduce(max)} days.'
        : 'Not enough logged cycles yet. Avenelle will calculate this after you log at least 2 period starts.';
    return PredictionResult(
      mostLikelyDate: likely,
      windowStart: likely.subtract(Duration(days: width)),
      windowEnd: likely.add(Duration(days: width)),
      confidence: confidence,
      recentTrend: trend,
      why: why,
      usualRangeLabel: usual,
    );
  }

  static double _weightedAverage(List<int> values) {
    final recent = values.reversed.take(4).toList();
    final weights = [0.40, 0.30, 0.20, 0.10];
    double total = 0;
    double weightTotal = 0;
    for (var i = 0; i < recent.length; i++) {
      total += recent[i] * weights[i];
      weightTotal += weights[i];
    }
    return total / weightTotal;
  }

  static int _variation(List<int> values) {
    if (values.length < 2) return 0;
    return values.reduce(max) - values.reduce(min);
  }

  static String _confidence(int cycleCount, int variation, String regularity) {
    if (cycleCount >= 4 && variation <= 3 && regularity == 'regular') return 'High';
    if (cycleCount >= 3 && variation <= 6) return 'Medium';
    return 'Low';
  }

  static String _trend(List<int> values) {
    if (values.length < 3) return 'Not enough data yet';
    final last3 = values.sublist(max(0, values.length - 3));
    if (last3[0] < last3[1] && last3[1] < last3[2]) return 'slightly lengthening';
    if (last3[0] > last3[1] && last3[1] > last3[2]) return 'slightly shortening';
    if (_variation(last3) <= 2) return 'stable';
    return 'variable';
  }

  static bool _hasRepeatedSymptom(AppData data, String symptom) {
    return data.symptomLogs.where((s) => s.name.toLowerCase() == symptom.toLowerCase()).length >= 2;
  }
}

class SignalWindowResult {
  SignalWindowResult({required this.available, required this.title, required this.body, required this.strength});
  final bool available;
  final String title;
  final String body;
  final String strength;
}

class SignalWindowEngine {
  static SignalWindowResult detect(AppData data) {
    if (!data.signalWindowEnabled) {
      return SignalWindowResult(available: false, title: 'Signal Window is off', body: 'Turn it on to track recurring pre-period symptom patterns.', strength: 'off');
    }
    final severe = data.symptomLogs.where((s) => s.severity == 'severe' && (s.category == 'mood' || s.category == 'body')).toList();
    if (severe.length < 2) {
      return SignalWindowResult(
        available: false,
        title: 'Not enough pattern history yet',
        body: 'Keep logging symptoms, severity, and impact to help Avenelle notice recurring pre-period patterns. ${SafetyCopy.signalWindowDisclaimer}',
        strength: 'low-data',
      );
    }
    final names = severe.map((e) => e.name).toSet().take(3).join(' or ');
    final strength = severe.length >= 4 ? 'Strong' : severe.length >= 3 ? 'Medium' : 'Weak';
    return SignalWindowResult(
      available: true,
      title: 'Recurring pre-period symptom window',
      body: 'Avenelle noticed that $names appeared before recent periods with higher severity or impact. This logged pattern may be useful to discuss with a clinician. ${SafetyCopy.signalWindowDisclaimer}',
      strength: strength,
    );
  }
}

class DoctorSummaryEngine {
  static String generate(AppData data, PredictionResult prediction, SignalWindowResult signal) {
    final generated = formatDate(DateTime.now());
    final periods = [...data.periodLogs]..sort((a, b) => a.startDate.compareTo(b.startDate));
    final last6 = periods.reversed.take(6).toList().reversed.toList();
    final validCycleLengths = PredictionEngine.validCycleLengths(data);
    final hasEnoughCycles = validCycleLengths.length >= 2;
    final avg = hasEnoughCycles ? (validCycleLengths.reduce((a, b) => a + b) / validCycleLengths.length).round().toString() : null;
    final shortest = hasEnoughCycles ? validCycleLengths.reduce(min).toString() : null;
    final longest = hasEnoughCycles ? validCycleLengths.reduce(max).toString() : null;
    final symptomNames = data.symptomLogs.where((s) => s.category != 'mood').map((s) => s.name).toSet().toList();
    final moodNames = data.symptomLogs.where((s) => s.category == 'mood').map((s) => s.name).toSet().toList();
    final periodHistory = last6.isEmpty
        ? '- No period history logged yet.'
        : last6.map((p) => '- ${formatDate(p.startDate)} ${p.endDate == null ? '(ongoing or end not logged)' : 'to ${formatDate(p.endDate!)}'}${p.excludedFromPrediction ? ' (excluded from predictions)' : ''}').join('\n');
    final flowPattern = data.flowLogs.isEmpty
        ? '- No flow entries logged yet.'
        : data.flowLogs.reversed.take(12).map((f) => '- ${formatDate(f.date)}: ${f.flowLevel}').join('\n');
    final symptomSummary = symptomNames.isEmpty ? '- No symptoms logged yet.' : symptomNames.map((symptom) => '- $symptom').join('\n');
    final moodSummary = moodNames.isEmpty ? '- No mood entries logged yet.' : moodNames.map((mood) => '- $mood').join('\n');
    final feedback = data.predictionFeedback.isEmpty ? '- No prediction feedback logged yet.' : '- Feedback entries: ${data.predictionFeedback.length}';
    final excludedCount = periods.where((p) => p.excludedFromPrediction).length;
    final cycleOverview = hasEnoughCycles
        ? '- Valid logged cycles included: ${validCycleLengths.length}\n- Average cycle length: $avg days\n- Shortest cycle: $shortest days\n- Longest cycle: $longest days${excludedCount > 0 ? '\n- Excluded unusual cycles: $excludedCount' : ''}'
        : '- Not enough valid cycle history yet.${excludedCount > 0 ? '\n- Excluded unusual cycles: $excludedCount' : ''}';
    return '''Avenelle Doctor Summary
Generated: $generated

${SafetyCopy.doctorSummaryDisclaimer}

Cycle Overview
$cycleOverview
- Current prediction: ${formatDate(prediction.mostLikelyDate)}
- Expected window: ${formatDate(prediction.windowStart)} to ${formatDate(prediction.windowEnd)}
- Confidence: ${prediction.confidence}

Period History
$periodHistory

Flow Logs
$flowPattern

Symptoms
$symptomSummary

Mood Logs
$moodSummary

Signal Window / Pre-Period Pattern
- ${signal.available ? signal.body : 'Not enough recurring pre-period pattern history yet.'}

Prediction Feedback
$feedback

Optional Notes
- Add your own notes before sharing with a clinician.
''';
  }
}

String formatDate(DateTime date) {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return '${months[date.month - 1]} ${date.day}, ${date.year}';
}

int daysBetween(DateTime a, DateTime b) => DateTime(a.year, a.month, a.day).difference(DateTime(b.year, b.month, b.day)).inDays;

bool sameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;
DateTime dateOnly(DateTime date) => DateTime(date.year, date.month, date.day);


Future<void> savePeriodStartWithGuardrail(BuildContext context, CycleRepository repository, DateTime date, {VoidCallback? afterSave}) async {
  var message = await repository.startPeriod(date);
  if (!context.mounted) return;
  if (message.startsWith('This is close to your last logged period')) {
    final saveAnyway = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Save as a new period start?'),
        content: const Text('This is close to your last logged period. Save it only if this is truly a new period start.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Save Anyway')),
        ],
      ),
    );
    if (saveAnyway == true) {
      message = await repository.startPeriod(date, saveAnyway: true);
    } else {
      message = 'Period start not saved.';
    }
  }
  afterSave?.call();
  if (context.mounted) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message), duration: const Duration(seconds: 2)));
  }
}


class AvenelleMark extends StatelessWidget {
  const AvenelleMark({super.key, this.size = 66});
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [AppTheme.plum, Color(0xFF7A426F)]),
        borderRadius: BorderRadius.circular(size * .34),
        boxShadow: [BoxShadow(color: AppTheme.plum.withOpacity(.24), blurRadius: 22, offset: const Offset(0, 9))],
      ),
      child: Stack(alignment: Alignment.center, children: [
        Container(width: size * .58, height: size * .58, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.white.withOpacity(.34), width: 2))),
        Icon(Icons.water_drop_rounded, color: Colors.white, size: size * .45),
        Positioned(right: size * .22, bottom: size * .20, child: Container(width: size * .16, height: size * .16, decoration: BoxDecoration(color: const Color(0xFFFFF8F1), borderRadius: BorderRadius.circular(size * .04))))
      ]),
    );
  }
}

class PremiumCard extends StatelessWidget {
  const PremiumCard({super.key, required this.child, this.padding = const EdgeInsets.all(20), this.color, this.hero = false});
  final Widget child;
  final EdgeInsets padding;
  final Color? color;
  final bool hero;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 16),
      padding: padding,
      decoration: BoxDecoration(
        color: color,
        gradient: color == null
            ? LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: hero
                    ? [const Color(0xFFFFEFE7), const Color(0xFFF5E8FF), const Color(0xFFFFFCF8)]
                    : [AppTheme.card, const Color(0xFFFFF6F3)],
              )
            : null,
        borderRadius: BorderRadius.circular(hero ? 32 : 26),
        border: Border.all(color: hero ? AppTheme.plum.withOpacity(.20) : AppTheme.softLine),
        boxShadow: [
          BoxShadow(color: AppTheme.plum.withOpacity(hero ? .12 : .055), blurRadius: hero ? 28 : 18, offset: const Offset(0, 12)),
          BoxShadow(color: Colors.white.withOpacity(.75), blurRadius: 10, offset: const Offset(-4, -4)),
        ],
      ),
      child: child,
    );
  }
}

class PremiumPill extends StatelessWidget {
  const PremiumPill({super.key, required this.label, this.icon, this.soft = false});
  final String label;
  final IconData? icon;
  final bool soft;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: soft ? AppTheme.lavender.withOpacity(.42) : Colors.white.withOpacity(.78),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: AppTheme.plum.withOpacity(.14)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        if (icon != null) ...[Icon(icon, size: 15, color: AppTheme.plum), const SizedBox(width: 6)],
        Text(label, style: const TextStyle(fontWeight: FontWeight.w800, color: AppTheme.charcoal, fontSize: 12)),
      ]),
    );
  }
}

class SectionKicker extends StatelessWidget {
  const SectionKicker(this.text, {super.key});
  final String text;

  @override
  Widget build(BuildContext context) => Text(
        text.toUpperCase(),
        style: TextStyle(letterSpacing: 1.1, color: AppTheme.plum.withOpacity(.68), fontWeight: FontWeight.w900, fontSize: 11),
      );
}

class AppLockGate extends StatefulWidget {
  const AppLockGate({super.key, required this.repository});
  final CycleRepository repository;

  @override
  State<AppLockGate> createState() => _AppLockGateState();
}

class _AppLockGateState extends State<AppLockGate> {
  bool unlocked = false;
  final controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final needsLock = widget.repository.data.appLockEnabled && widget.repository.data.pinCode != null && !unlocked;
    if (!needsLock) return MainShell(repository: widget.repository);
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('Private lock', style: Theme.of(context).textTheme.headlineMedium, textAlign: TextAlign.center),
              const SizedBox(height: 12),
              const Text('Enter your PIN to open Avenelle.', textAlign: TextAlign.center),
              const SizedBox(height: 20),
              TextField(controller: controller, obscureText: true, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'PIN')),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: () {
                  if (controller.text == widget.repository.data.pinCode) setState(() => unlocked = true);
                },
                child: const Text('Unlock'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key, required this.repository});
  final CycleRepository repository;

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  int step = 0;
  DateTime lastStart = DateTime.now().subtract(const Duration(days: 28));
  int periodLength = 5;
  bool signalWindow = true;
  bool privateNotifications = true;

  void _next() => setState(() => step++);
  void _back() {
    if (step > 0) setState(() => step--);
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      _onboardCard(
        title: 'Avenelle',
        subtitle: 'Period Tracker & Cycle Insights',
        body: 'Track your period, understand your patterns, and prepare with clearer prediction windows.',
        button: 'Get Started',
      ),
      _onboardCard(
        title: 'Your cycle data should stay yours',
        subtitle: 'Private by design',
        body: 'Private notifications are default. No automatic sharing. Export and delete stay under your control.',
        button: 'Continue',
      ),
      _cycleBasics(),
      _trackingGoals(),
      _signalWindowOptIn(),
      _notificationChoice(),
      _setupComplete(),
    ];
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 16, 22, 24),
          child: Column(
            children: [
              Row(children: [
                if (step > 0)
                  IconButton(onPressed: _back, icon: const Icon(Icons.arrow_back_rounded))
                else
                  const SizedBox(width: 48),
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(999),
                    child: LinearProgressIndicator(value: (step + 1) / screens.length, color: AppTheme.plum, backgroundColor: AppTheme.lavender.withOpacity(.35), minHeight: 6),
                  ),
                ),
                const SizedBox(width: 48),
              ]),
              const SizedBox(height: 10),
              Expanded(child: AnimatedSwitcher(duration: const Duration(milliseconds: 220), child: KeyedSubtree(key: ValueKey(step), child: screens[step]))),
            ],
          ),
        ),
      ),
    );
  }

  Widget _onboardCard({required String title, required String subtitle, required String body, required String button}) => Center(
        child: ListView(
          shrinkWrap: true,
          children: [
            PremiumCard(
              hero: true,
              padding: const EdgeInsets.fromLTRB(26, 34, 26, 34),
              child: Column(children: [
                const AvenelleMark(size: 66),
                const SizedBox(height: 20),
                Text(title, style: Theme.of(context).textTheme.headlineLarge, textAlign: TextAlign.center),
                const SizedBox(height: 10),
                Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 18),
                Text(body, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyLarge),
              ]),
            ),
            const SizedBox(height: 8),
            FilledButton(onPressed: _next, child: Text(button)),
          ],
        ),
      );

  Widget _cycleBasics() => ListView(
        children: [
          const SectionKicker('Private setup'),
          Text('Cycle basics', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 12),
          PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Last period start', style: TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text(formatDate(lastStart), style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            FilledButton.icon(onPressed: () async {
              final picked = await showDatePicker(context: context, initialDate: lastStart, firstDate: DateTime(2020), lastDate: DateTime.now().add(const Duration(days: 1)));
              if (picked != null) setState(() => lastStart = picked);
            }, icon: const Icon(Icons.calendar_month_rounded), label: const Text('Choose Date')),
          ])),
          PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Period length: $periodLength days', style: Theme.of(context).textTheme.titleMedium),
            Slider(value: periodLength.toDouble(), min: 2, max: 10, divisions: 8, label: '$periodLength days', onChanged: (v) => setState(() => periodLength = v.round())),
            const Text('You can adjust this later as your logged history grows.'),
          ])),
          FilledButton(onPressed: _next, child: const Text('Continue')),
        ],
      );

  Widget _trackingGoals() => _choiceScreen('Tracking goals', 'Avenelle will focus on period dates, flow, symptoms, mood, prep, privacy, and doctor-ready summaries.', 'Continue');

  Widget _signalWindowOptIn() => ListView(children: [
        Text('Track recurring pre-period symptoms?', style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 12),
        const PremiumCard(child: Text('Avenelle can help you notice recurring pre-period symptom windows by tracking timing, severity, and impact. This does not diagnose any condition.')),
        PremiumCard(child: SwitchListTile(value: signalWindow, title: const Text('Turn On Signal Window'), subtitle: const Text('Pattern support stays non-diagnostic and private.'), onChanged: (v) => setState(() => signalWindow = v))),
        FilledButton(onPressed: _next, child: const Text('Continue')),
      ]);

  Widget _notificationChoice() => ListView(children: [
        Text('Notification privacy', style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 12),
        PremiumCard(child: Column(children: [
          RadioListTile(value: true, groupValue: privateNotifications, title: const Text('Private reminder'), subtitle: const Text('“Avenelle reminder ready.”'), onChanged: (v) => setState(() => privateNotifications = true)),
          RadioListTile(value: false, groupValue: privateNotifications, title: const Text('Detailed reminder'), subtitle: const Text('“Your period may start soon.”'), onChanged: (v) => setState(() => privateNotifications = false)),
        ])),
        FilledButton(onPressed: _next, child: const Text('Continue')),
      ]);

  Widget _setupComplete() => Center(child: ListView(shrinkWrap: true, children: [
        PremiumCard(hero: true, child: Column(children: [
          const Icon(Icons.verified_rounded, color: AppTheme.plum, size: 44),
          const SizedBox(height: 14),
          Text('You’re ready', style: Theme.of(context).textTheme.headlineMedium, textAlign: TextAlign.center),
          const SizedBox(height: 14),
          const Text('Avenelle will start with your current cycle and improve as you log periods, symptoms, and feedback.', textAlign: TextAlign.center),
        ])),
        FilledButton(
            onPressed: () => widget.repository.completeOnboarding(lastStart, periodLength, [], signalWindow, privateNotifications),
            child: const Text('Go to Today')),
      ]));

  Widget _choiceScreen(String title, String body, String button) => Center(child: ListView(shrinkWrap: true, children: [
        PremiumCard(hero: true, child: Column(children: [
          Text(title, style: Theme.of(context).textTheme.headlineMedium, textAlign: TextAlign.center),
          const SizedBox(height: 16),
          Text(body, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyLarge),
        ])),
        FilledButton(onPressed: _next, child: Text(button)),
      ]));
}

class MainShell extends StatefulWidget {
  const MainShell({super.key, required this.repository});
  final CycleRepository repository;

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final screens = [
      TodayScreen(repository: widget.repository),
      CalendarScreen(repository: widget.repository),
      LogScreen(repository: widget.repository),
      InsightsScreen(repository: widget.repository),
      CareScreen(repository: widget.repository),
    ];
    return Scaffold(
      body: SafeArea(child: screens[index]),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: AppTheme.card,
          border: Border(top: BorderSide(color: AppTheme.softLine.withOpacity(.8))),
          boxShadow: [BoxShadow(color: AppTheme.plum.withOpacity(.08), blurRadius: 20, offset: const Offset(0, -8))],
        ),
        child: BottomNavigationBar(
          currentIndex: index,
          onTap: (i) => setState(() => index = i),
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.today_rounded), label: 'Today'),
            BottomNavigationBarItem(icon: Icon(Icons.calendar_month_rounded), label: 'Calendar'),
            BottomNavigationBarItem(icon: Icon(Icons.add_circle_outline_rounded), label: 'Log'),
            BottomNavigationBarItem(icon: Icon(Icons.auto_graph_rounded), label: 'Insights'),
            BottomNavigationBarItem(icon: Icon(Icons.favorite_border_rounded), label: 'Care'),
          ],
        ),
      ),
    );
  }
}

class TodayScreen extends StatelessWidget {
  const TodayScreen({super.key, required this.repository});
  final CycleRepository repository;

  void _snack(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message), duration: const Duration(seconds: 2)));
  }

  Future<void> _quickMood(BuildContext context) async {
    final mood = await showModalBottomSheet<String>(
      context: context,
      builder: (_) => Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('Log mood', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 10),
            for (final m in ['Calm', 'Anxious', 'Irritated', 'Overwhelmed'])
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: OutlinedButton(onPressed: () => Navigator.pop(context, m), child: Text(m)),
              ),
          ],
        ),
      ),
    );
    if (mood != null) {
      await repository.addSymptom('mood', mood, mood == 'Calm' ? 'mild' : 'moderate', 'normal day', improvedAfterPeriod: 'not sure');
      if (context.mounted) _snack(context, 'Mood logged for today.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = repository.prediction;
    final signal = repository.signalWindow;
    final today = dateOnly(DateTime.now());
    final periodToday = repository.data.periodLogs.any((log) => sameDay(log.startDate, today));
    final heavyToday = repository.data.flowLogs.any((f) => sameDay(f.date, today) && f.flowLevel == 'heavy');
    final crampsToday = repository.data.symptomLogs.any((symptom) => sameDay(symptom.date, today) && symptom.name == 'Cramps');
    final moodToday = repository.data.symptomLogs.any((symptom) => sameDay(symptom.date, today) && symptom.category == 'mood');
    final cycleDayValue = repository.data.lastPeriodStart == null ? null : max(1, daysBetween(DateTime.now(), repository.data.lastPeriodStart!) + 1);
    final cycleDay = cycleDayValue == null ? 'Not enough data yet' : '$cycleDayValue';
    final todayFlow = repository.flowFor(today)?.flowLevel;
    final todaySymptoms = repository.symptomsFor(today).where((s) => s.category != 'mood').map((s) => s.name).toSet().toList();
    final todayMood = repository.symptomsFor(today, category: 'mood').map((s) => s.name).toSet().toList();
    return ScreenPadding(children: [
      Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SectionKicker('Private cycle dashboard'),
          Text('Today', style: Theme.of(context).textTheme.headlineLarge),
          Text('Cycle Day $cycleDay', style: const TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF6F636B))),
        ])),
        const AvenelleMark(size: 48),
      ]),
      const SizedBox(height: 10),
      PremiumCard(
        hero: true,
        padding: const EdgeInsets.all(24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const PremiumPill(label: 'TrueWindow', icon: Icons.auto_graph_rounded, soft: true),
            const Spacer(),
            PremiumPill(label: '${p.confidence} confidence', icon: Icons.verified_rounded),
          ]),
          const SizedBox(height: 18),
          const SectionKicker('Period prediction'),
          const SizedBox(height: 6),
          Text(formatDate(p.mostLikelyDate), style: Theme.of(context).textTheme.headlineLarge),
          const SizedBox(height: 8),
          Text('Expected window: ${formatDate(p.windowStart)} – ${formatDate(p.windowEnd)}', style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 16),
          Container(height: 1, color: AppTheme.plum.withOpacity(.12)),
          const SizedBox(height: 14),
          Text('Why this prediction?', style: Theme.of(context).textTheme.titleMedium),
          ...p.why.map((w) => Padding(padding: const EdgeInsets.only(top: 7), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Icon(Icons.check_circle_rounded, color: AppTheme.plum.withOpacity(.72), size: 17),
                const SizedBox(width: 8),
                Expanded(child: Text(w)),
              ]))),
        ]),
      ),
      PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Quick Log', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, children: [
          FilterChip(selected: periodToday, avatar: const Icon(Icons.play_circle_rounded, size: 18), label: const Text('Start Period'), onSelected: (_) async => savePeriodStartWithGuardrail(context, repository, DateTime.now())),
          FilterChip(selected: heavyToday, avatar: const Icon(Icons.water_drop_rounded, size: 18), label: const Text('Heavy Flow'), onSelected: (_) async { await repository.addFlow('heavy'); if (context.mounted) _snack(context, 'Heavy flow logged for today.'); }),
          FilterChip(selected: crampsToday, avatar: const Icon(Icons.healing_rounded, size: 18), label: const Text('Cramps'), onSelected: (_) async { await repository.addSymptom('pain', 'Cramps', 'moderate', 'normal day'); if (context.mounted) _snack(context, 'Cramps logged for today.'); }),
          FilterChip(selected: moodToday, avatar: const Icon(Icons.mood_rounded, size: 18), label: const Text('Mood'), onSelected: (_) => _quickMood(context)),
        ]),
      ])),
      PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Today’s saved logs', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 8),
        Text('Period: ${repository.periodCovers(today) ? 'Active / logged' : 'Not logged today'}'),
        Text('Flow: ${todayFlow ?? 'No flow logged'}'),
        Text('Symptoms: ${todaySymptoms.isEmpty ? 'No symptoms logged' : todaySymptoms.join(', ')}'),
        Text('Mood: ${todayMood.isEmpty ? 'No mood logged' : todayMood.join(', ')}'),
        const SizedBox(height: 10),
        OutlinedButton.icon(onPressed: () async { await repository.deleteLogsForDay(today); if (context.mounted) _snack(context, 'Today’s logs cleared.'); }, icon: const Icon(Icons.edit_note_rounded), label: const Text('Clear Today’s Logs')),
      ])),
      PremiumCard(child: Text('Prep Mode\nYour period may start within the next few days. Check supplies, set a reminder, and pack extras if needed.', style: Theme.of(context).textTheme.bodyLarge)),
      PremiumCard(child: Text('${signal.title}\n\n${signal.body}')),
    ]);
  }
}

class CalendarScreen extends StatefulWidget {
  const CalendarScreen({super.key, required this.repository});
  final CycleRepository repository;

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  late DateTime visibleMonth = DateTime(DateTime.now().year, DateTime.now().month, 1);

  void _snack(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message), duration: const Duration(seconds: 2)));
  }

  Future<void> _chooseFlow(DateTime day) async {
    final selected = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      backgroundColor: AppTheme.cream,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(30))),
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 8, 22, 22),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text('Edit flow', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            for (final f in ['spotting', 'light', 'medium', 'heavy'])
              Padding(padding: const EdgeInsets.only(bottom: 8), child: OutlinedButton(onPressed: () => Navigator.pop(context, f), child: Text(f[0].toUpperCase() + f.substring(1)))),
            TextButton(onPressed: () => Navigator.pop(context, 'clear'), child: const Text('Clear flow for this day')),
          ]),
        ),
      ),
    );
    if (selected == null) return;
    if (selected == 'clear') {
      await widget.repository.clearFlow(date: day);
      if (mounted) setState(() {});
      if (mounted) _snack(context, 'Flow cleared for ${formatDate(day)}.');
      return;
    }
    await widget.repository.addFlow(selected, date: day);
    if (mounted) setState(() {});
    if (mounted) _snack(context, '${selected[0].toUpperCase() + selected.substring(1)} flow saved for ${formatDate(day)}.');
  }

  Future<void> _chooseMood(DateTime day) async {
    final selected = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      backgroundColor: AppTheme.cream,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(30))),
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 8, 22, 22),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text('Edit mood', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            for (final m in ['Calm', 'Anxious', 'Irritated', 'Overwhelmed'])
              Padding(padding: const EdgeInsets.only(bottom: 8), child: OutlinedButton(onPressed: () => Navigator.pop(context, m), child: Text(m))),
            TextButton(onPressed: () => Navigator.pop(context, 'clear'), child: const Text('Clear mood for this day')),
          ]),
        ),
      ),
    );
    if (selected == null) return;
    if (selected == 'clear') {
      await widget.repository.clearMood(date: day);
      if (mounted) setState(() {});
      if (mounted) _snack(context, 'Mood cleared for ${formatDate(day)}.');
      return;
    }
    await widget.repository.addSymptom('mood', selected, selected == 'Calm' ? 'mild' : 'moderate', 'normal day', date: day, improvedAfterPeriod: 'not sure');
    if (mounted) setState(() {});
    if (mounted) _snack(context, '$selected mood saved for ${formatDate(day)}.');
  }

  Future<void> _chooseSymptom(DateTime day) async {
    final selected = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      backgroundColor: AppTheme.cream,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(30))),
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 8, 22, 22),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text('Edit symptoms', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            for (final s in ['Cramps', 'Back pain', 'Headache', 'Bloating', 'Fatigue', 'Cravings'])
              Padding(padding: const EdgeInsets.only(bottom: 8), child: OutlinedButton(onPressed: () => Navigator.pop(context, s), child: Text(s))),
          ]),
        ),
      ),
    );
    if (selected == null) return;
    final category = ['Cramps', 'Back pain', 'Headache'].contains(selected) ? 'pain' : 'body';
    await widget.repository.addSymptom(category, selected, 'moderate', 'normal day', date: day, improvedAfterPeriod: 'not sure');
    if (mounted) setState(() {});
    if (mounted) _snack(context, '$selected saved for ${formatDate(day)}.');
  }

  Future<void> _clearDay(DateTime day) async {
    final confirm = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('Clear this day?'),
      content: Text('Remove period, flow, symptoms, and mood logs saved for ${formatDate(day)}?'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Clear Day')),
      ],
    ));
    if (confirm == true) {
      await widget.repository.deleteLogsForDay(day);
      if (mounted) setState(() {});
      if (mounted) _snack(context, 'Logs cleared for ${formatDate(day)}.');
    }
  }

  void _openDayDetail(DateTime day) {
    final repo = widget.repository;
    final p = repo.prediction;
    final flow = repo.flowFor(day);
    final symptoms = repo.symptomsFor(day).where((s) => s.category != 'mood').map((s) => s.name).toSet().toList();
    final moods = repo.symptomsFor(day, category: 'mood').map((s) => s.name).toSet().toList();
    final isPeriod = repo.periodCovers(day);
    final inWindow = !day.isBefore(p.windowStart) && !day.isAfter(p.windowEnd);
    final hasAnything = isPeriod || flow != null || symptoms.isNotEmpty || moods.isNotEmpty;
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      backgroundColor: AppTheme.cream,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(30))),
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 4, 22, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(children: [
                Expanded(child: Text(formatDate(day), style: Theme.of(context).textTheme.titleLarge)),
                PremiumPill(label: inWindow ? 'Inside window' : 'Outside window', icon: Icons.auto_graph_rounded, soft: inWindow),
              ]),
              const SizedBox(height: 12),
              PremiumCard(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                if (!hasAnything) const Text('Nothing logged for this day yet.'),
                Text('Period: ${isPeriod ? 'Logged' : 'Not logged'}'),
                Text('Flow: ${flow == null ? 'No flow logged' : flow.flowLevel}'),
                Text('Symptoms: ${symptoms.isEmpty ? 'No symptoms logged' : symptoms.join(', ')}'),
                Text('Mood: ${moods.isEmpty ? 'No mood logged' : moods.join(', ')}'),
              ])),
              Wrap(spacing: 8, runSpacing: 8, children: [
                ActionChip(label: const Text('Log Period'), avatar: const Icon(Icons.play_circle_rounded), onPressed: () async { Navigator.pop(context); await savePeriodStartWithGuardrail(context, repo, day, afterSave: () { if (mounted) setState(() {}); }); }),
                ActionChip(label: const Text('Edit Flow'), avatar: const Icon(Icons.water_drop_rounded), onPressed: () { Navigator.pop(context); _chooseFlow(day); }),
                ActionChip(label: const Text('Edit Symptoms'), avatar: const Icon(Icons.healing_rounded), onPressed: () { Navigator.pop(context); _chooseSymptom(day); }),
                ActionChip(label: const Text('Edit Mood'), avatar: const Icon(Icons.mood_rounded), onPressed: () { Navigator.pop(context); _chooseMood(day); }),
                ActionChip(label: const Text('Clear Day'), avatar: const Icon(Icons.delete_outline_rounded), onPressed: () { Navigator.pop(context); _clearDay(day); }),
              ]),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final repo = widget.repository;
    final p = repo.prediction;
    final daysInMonth = DateTime(visibleMonth.year, visibleMonth.month + 1, 0).day;
    final today = dateOnly(DateTime.now());
    return ScreenPadding(children: [
      Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SectionKicker('Pattern map'),
          Text('Calendar', style: Theme.of(context).textTheme.headlineLarge),
        ])),
        IconButton(onPressed: () => setState(() => visibleMonth = DateTime(visibleMonth.year, visibleMonth.month - 1, 1)), icon: const Icon(Icons.chevron_left)),
        IconButton(onPressed: () => setState(() => visibleMonth = DateTime(DateTime.now().year, DateTime.now().month, 1)), icon: const Icon(Icons.today)),
        IconButton(onPressed: () => setState(() => visibleMonth = DateTime(visibleMonth.year, visibleMonth.month + 1, 1)), icon: const Icon(Icons.chevron_right)),
      ]),
      Text('${formatDate(visibleMonth).split(' ').first} ${visibleMonth.year}', style: const TextStyle(fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      PremiumCard(child: Column(children: [
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: daysInMonth,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 7, childAspectRatio: 1),
          itemBuilder: (context, i) {
            final day = DateTime(visibleMonth.year, visibleMonth.month, i + 1);
            final inWindow = !day.isBefore(p.windowStart) && !day.isAfter(p.windowEnd);
            final likely = sameDay(day, p.mostLikelyDate);
            final isToday = sameDay(day, today);
            final isPeriod = repo.periodCovers(day);
            final hasLogs = repo.data.flowLogs.any((f) => sameDay(f.date, day)) || repo.data.symptomLogs.any((sym) => sameDay(sym.date, day));
            return Semantics(
              button: true,
              label: 'Calendar day ${day.day}${isPeriod ? ', period logged' : ''}${inWindow ? ', prediction window' : ''}${likely ? ', most likely start' : ''}',
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => _openDayDetail(day),
                child: Container(
                  margin: const EdgeInsets.all(3),
                  decoration: BoxDecoration(
                    color: isPeriod ? AppTheme.blush : inWindow ? AppTheme.lavender.withOpacity(.45) : isToday ? AppTheme.card : Colors.transparent,
                    border: Border.all(color: likely ? AppTheme.plum : hasLogs ? AppTheme.plum.withOpacity(.55) : isToday ? AppTheme.plum.withOpacity(.35) : AppTheme.softLine, width: likely ? 2.4 : isToday ? 1.6 : 1),
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: likely ? [BoxShadow(color: AppTheme.plum.withOpacity(.14), blurRadius: 12, offset: const Offset(0, 5))] : null,
                  ),
                  child: Stack(children: [
                    Center(child: Text('${day.day}', style: TextStyle(fontWeight: likely || hasLogs || isToday ? FontWeight.w900 : FontWeight.w600))),
                    if (hasLogs)
                      Positioned(bottom: 5, left: 0, right: 0, child: Center(child: Container(width: 5, height: 5, decoration: const BoxDecoration(color: AppTheme.plum, shape: BoxShape.circle)))),
                  ]),
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 14),
        const Text('Legend: blush = logged period, lavender = expected window, plum outline = most likely start'),
      ])),
      PremiumCard(child: Text('Expected period window: ${formatDate(p.windowStart)} – ${formatDate(p.windowEnd)}\nMost likely: ${formatDate(p.mostLikelyDate)}')),
    ]);
  }
}

class LogScreen extends StatelessWidget {
  const LogScreen({super.key, required this.repository});
  final CycleRepository repository;

  void _snack(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message), duration: const Duration(seconds: 2)));
  }

  @override
  Widget build(BuildContext context) {
    return ScreenPadding(children: [
      Text('Log Today', style: Theme.of(context).textTheme.headlineLarge),
      PremiumCard(child: _buttonGrid(context, 'Period', {
        'Start Period': () async => savePeriodStartWithGuardrail(context, repository, DateTime.now()),
        'End Period': () async { await repository.endLatestPeriod(DateTime.now()); _snack(context, 'Period ended for today.'); },
      })),
      PremiumCard(child: _buttonGrid(context, 'Flow', {
        'Spotting': () async { await repository.addFlow('spotting'); _snack(context, 'Spotting flow logged for today.'); },
        'Light': () async { await repository.addFlow('light'); _snack(context, 'Light flow logged for today.'); },
        'Medium': () async { await repository.addFlow('medium'); _snack(context, 'Medium flow logged for today.'); },
        'Heavy': () async { await repository.addFlow('heavy'); _snack(context, 'Heavy flow logged for today.'); },
      })),
      PremiumCard(child: _buttonGrid(context, 'Pain', {
        'Cramps': () => _addSymptom(context, 'pain', 'Cramps'),
        'Back pain': () => _addSymptom(context, 'pain', 'Back pain'),
        'Headache': () => _addSymptom(context, 'pain', 'Headache'),
      })),
      PremiumCard(child: _buttonGrid(context, 'Mood', {
        'Calm': () => _addSymptom(context, 'mood', 'Calm'),
        'Anxious': () => _addSymptom(context, 'mood', 'Anxious'),
        'Irritated': () => _addSymptom(context, 'mood', 'Irritated'),
        'Overwhelmed': () => _addSymptom(context, 'mood', 'Overwhelmed'),
      })),
      PremiumCard(child: _buttonGrid(context, 'Body', {
        'Bloating': () => _addSymptom(context, 'body', 'Bloating'),
        'Fatigue': () => _addSymptom(context, 'body', 'Fatigue'),
        'Cravings': () => _addSymptom(context, 'body', 'Cravings'),
      })),
    ]);
  }

  Widget _buttonGrid(BuildContext context, String title, Map<String, Future<void> Function()> actions) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: actions.entries
              .map((e) => FilterChip(
                    selected: _isSelected(title, e.key),
                    label: Text(e.key),
                    onSelected: (_) async => await e.value(),
                  ))
              .toList(),
        ),
      ]);

  bool _isSelected(String title, String label) {
    final today = dateOnly(DateTime.now());
    if (title == 'Period' && label == 'Start Period') {
      return repository.data.periodLogs.any((log) => sameDay(log.startDate, today));
    }
    if (title == 'Period' && label == 'End Period') {
      return repository.data.periodLogs.any((log) => log.endDate != null && sameDay(log.endDate!, today));
    }
    if (title == 'Flow') {
      return repository.data.flowLogs.any((flow) => sameDay(flow.date, today) && flow.flowLevel.toLowerCase() == label.toLowerCase());
    }
    if (title == 'Pain') {
      return repository.data.symptomLogs.any((symptom) => sameDay(symptom.date, today) && symptom.category == 'pain' && symptom.name == label);
    }
    if (title == 'Mood') {
      return repository.data.symptomLogs.any((symptom) => sameDay(symptom.date, today) && symptom.category == 'mood' && symptom.name == label);
    }
    if (title == 'Body') {
      return repository.data.symptomLogs.any((symptom) => sameDay(symptom.date, today) && symptom.category == 'body' && symptom.name == label);
    }
    return false;
  }

  Future<void> _addSymptom(BuildContext context, String category, String name) async {
    String severity = 'mild';
    String impact = 'normal day';
    await showModalBottomSheet(
      context: context,
      showDragHandle: true,
      backgroundColor: AppTheme.cream,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(30))),
      builder: (_) => StatefulBuilder(builder: (context, setState) => Padding(
            padding: const EdgeInsets.all(22),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Text('Log $name', style: Theme.of(context).textTheme.titleLarge),
              DropdownButton<String>(value: severity, items: ['mild', 'moderate', 'severe'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => severity = v!)),
              DropdownButton<String>(value: impact, items: ['normal day', 'hard day', 'missed work/school', 'conflict', 'needed help'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => impact = v!)),
              FilledButton(onPressed: () async { await repository.addSymptom(category, name, severity, impact, improvedAfterPeriod: 'not sure'); if (context.mounted) { Navigator.pop(context); _snack(context, '$name logged for today.'); } }, child: const Text('Save Log')),
            ]),
          )),
    );
  }
}

class InsightsScreen extends StatelessWidget {
  const InsightsScreen({super.key, required this.repository});
  final CycleRepository repository;

  void _snack(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message), duration: const Duration(seconds: 2)));
  }

  @override
  Widget build(BuildContext context) {
    final p = repository.prediction;
    final signal = repository.signalWindow;
    final enoughHeavy = repository.data.flowLogs.where((f) => f.flowLevel == 'heavy').length;
    final cycleCount = PredictionEngine.validCycleLengths(repository.data).length;
    final latestFeedback = repository.data.predictionFeedback.isEmpty ? null : repository.data.predictionFeedback.last.result;
    return ScreenPadding(children: [
      const SectionKicker('Private pattern view'),
      Text('Your Cycle Insights', style: Theme.of(context).textTheme.headlineLarge),
      PremiumCard(hero: true, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const PremiumPill(label: 'TrueWindow', icon: Icons.auto_graph_rounded, soft: true),
          const Spacer(),
          PremiumPill(label: '${p.confidence} confidence', icon: Icons.verified_rounded),
        ]),
        const SizedBox(height: 16),
        Text('Most likely: ${formatDate(p.mostLikelyDate)}', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 6),
        Text('Expected window: ${formatDate(p.windowStart)} – ${formatDate(p.windowEnd)}'),
      ])),
      PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Why This Prediction', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 8),
        ...p.why.map((w) => Padding(padding: const EdgeInsets.only(bottom: 8), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(Icons.check_circle_rounded, color: AppTheme.plum.withOpacity(.72), size: 18),
          const SizedBox(width: 8),
          Expanded(child: Text(w)),
        ]))),
      ])),
      PremiumCard(child: Text('Recent Trend\n${cycleCount >= 3 ? p.recentTrend : 'Not enough logged cycles yet.'}')),
      PremiumCard(child: Text('Normal for Me?\n${cycleCount >= 2 ? p.usualRangeLabel : 'Not enough logged cycles yet. Avenelle will calculate this after you log at least 2 period starts.'}')),
      PremiumCard(child: Text('Heavy Day Pattern\n${enoughHeavy == 0 ? 'No heavy flow entries logged yet.' : 'Heavy flow entries: $enoughHeavy. Keep logging flow to refine your usual heavy day.'}')),
      PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Pattern Timeline', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 8),
        const Text('Before period: keep logging symptoms before your expected window.\nDuring period: flow and pain logs will reveal your usual pattern.\nAfter period: Avenelle will keep summaries calm, private, and non-diagnostic.'),
      ])),
      PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Text('Signal Window', style: Theme.of(context).textTheme.titleLarge), const Spacer(), PremiumPill(label: signal.strength, icon: Icons.shield_rounded, soft: true)]),
        const SizedBox(height: 8),
        Text(signal.body),
      ])),
      PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Prediction Feedback', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 4),
        Text(latestFeedback == null ? 'Was Avenelle right?' : 'Saved: $latestFeedback'),
        const SizedBox(height: 10),
        Wrap(spacing: 8, children: [
          FilterChip(selected: latestFeedback == 'accurate', label: const Text('Accurate'), onSelected: (_) async { await repository.addFeedback('accurate', 0); if (context.mounted) _snack(context, 'Feedback saved. Avenelle will use this to improve future windows.'); }),
          FilterChip(selected: latestFeedback == 'early', label: const Text('Early'), onSelected: (_) async { await repository.addFeedback('early', 2); if (context.mounted) _snack(context, 'Feedback saved. Avenelle will use this to improve future windows.'); }),
          FilterChip(selected: latestFeedback == 'late', label: const Text('Late'), onSelected: (_) async { await repository.addFeedback('late', 2); if (context.mounted) _snack(context, 'Feedback saved. Avenelle will use this to improve future windows.'); }),
        ]),
      ])),
    ]);
  }
}

class CareScreen extends StatelessWidget {
  const CareScreen({super.key, required this.repository});
  final CycleRepository repository;

  @override
  Widget build(BuildContext context) {
    final p = repository.prediction;
    final currentCycleDay = repository.data.lastPeriodStart == null ? null : max(1, daysBetween(DateTime.now(), repository.data.lastPeriodStart!) + 1);
    return ScreenPadding(children: [
      const SectionKicker('Support without diagnosis'),
      Text('Care', style: Theme.of(context).textTheme.headlineLarge),
      PremiumCard(hero: true, child: Text('Prep Mode\nYour period may start around ${formatDate(p.mostLikelyDate)}. Prepare supplies, pain relief if you use it, water, and backup items.', style: Theme.of(context).textTheme.bodyLarge)),
      PremiumCard(child: const Text('Heavy Day Prep\nYour heavy-day pattern will become clearer as you log flow during each period.')),
      PremiumCard(child: Text("Late Period Calm Mode\nCurrent cycle day: ${currentCycleDay ?? 'Not enough data yet'}\n${SafetyCopy.latePeriodDisclaimer}")),
      PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Doctor Summary', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 6),
        const Text('Create a clean cycle report from your logs. Nothing is sent automatically.'),
        const SizedBox(height: 12),
        FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DoctorSummaryScreen(repository: repository))), icon: const Icon(Icons.description_rounded), label: const Text('Create Summary')),
      ])),
      PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Pattern Timeline', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 6),
        const Text('Before period: Avenelle will show recurring pre-period patterns after more history.\nDuring period: flow and symptoms appear as you log them.\nAfter period: reflection notes can support cleaner summaries.'),
        const SizedBox(height: 10),
        const Wrap(spacing: 8, runSpacing: 8, children: [
          PremiumPill(label: 'Before', icon: Icons.nightlight_round, soft: true),
          PremiumPill(label: 'During', icon: Icons.water_drop_rounded, soft: true),
          PremiumPill(label: 'After', icon: Icons.wb_sunny_rounded, soft: true),
        ]),
      ])),
      PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Cycle History', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 6),
        const Text('Review period starts, correct mistakes, and exclude unusual cycles from prediction averages.'),
        const SizedBox(height: 12),
        OutlinedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CycleHistoryScreen(repository: repository))), icon: const Icon(Icons.edit_calendar_rounded), label: const Text('Review Cycle History')),
      ])),
      PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Privacy Vault', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 6),
        const Text('Private notifications, app lock, export, delete, no automatic sharing, no ad targeting from cycle data.'),
        const SizedBox(height: 12),
        FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PrivacyVaultScreen(repository: repository))), icon: const Icon(Icons.lock_rounded), label: const Text('Open Privacy Settings')),
      ])),
    ]);
  }
}


class CycleHistoryScreen extends StatelessWidget {
  const CycleHistoryScreen({super.key, required this.repository});
  final CycleRepository repository;

  Future<void> _pickDate(BuildContext context, PeriodLog log, bool start) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: start ? log.startDate : (log.endDate ?? log.startDate),
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked == null) return;
    if (start) {
      await repository.updatePeriodLog(log.id, startDate: picked);
    } else {
      await repository.updatePeriodLog(log.id, endDate: picked);
    }
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Cycle history updated.')));
  }

  @override
  Widget build(BuildContext context) {
    final logs = [...repository.data.periodLogs]..sort((a, b) => b.startDate.compareTo(a.startDate));
    return Scaffold(
      appBar: AppBar(title: const Text('Cycle History')),
      body: ScreenPadding(children: [
        PremiumCard(hero: true, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Correct your history', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          const Text('Edit mistaken dates or exclude unusual cycles so predictions stay honest. Excluded cycles still remain in your history and Doctor Summary.'),
        ])),
        if (logs.isEmpty) const PremiumCard(child: Text('No period history logged yet.')),
        for (final log in logs)
          PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: Text('${formatDate(log.startDate)}${log.endDate == null ? ' • ongoing' : ' – ${formatDate(log.endDate!)}'}', style: Theme.of(context).textTheme.titleMedium)),
              PremiumPill(label: log.excludedFromPrediction ? 'Excluded' : 'Included', icon: log.excludedFromPrediction ? Icons.visibility_off_rounded : Icons.check_circle_rounded, soft: true),
            ]),
            const SizedBox(height: 10),
            Wrap(spacing: 8, runSpacing: 8, children: [
              ActionChip(label: const Text('Edit Start'), avatar: const Icon(Icons.calendar_month_rounded), onPressed: () => _pickDate(context, log, true)),
              ActionChip(label: const Text('Edit End'), avatar: const Icon(Icons.event_available_rounded), onPressed: () => _pickDate(context, log, false)),
              ActionChip(label: Text(log.excludedFromPrediction ? 'Include in Prediction' : 'Exclude from Prediction'), avatar: const Icon(Icons.auto_graph_rounded), onPressed: () async { await repository.updatePeriodLog(log.id, excludedFromPrediction: !log.excludedFromPrediction); }),
              ActionChip(label: const Text('Delete'), avatar: const Icon(Icons.delete_outline_rounded), onPressed: () async { await repository.deletePeriodLog(log.id); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Period log deleted.'))); }),
            ]),
          ])),
      ]),
    );
  }
}

class DoctorSummaryScreen extends StatelessWidget {
  const DoctorSummaryScreen({super.key, required this.repository});
  final CycleRepository repository;

  @override
  Widget build(BuildContext context) {
    final summary = repository.doctorSummary;
    return Scaffold(
      appBar: AppBar(title: const Text('Doctor Summary')),
      body: ScreenPadding(children: [
        PremiumCard(hero: true, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: const [Icon(Icons.verified_user_rounded, color: AppTheme.plum), SizedBox(width: 8), Expanded(child: Text('Share only when you choose.'))]),
          const SizedBox(height: 8),
          const Text('This report is generated from local Avenelle logs and does not diagnose any condition.'),
        ])),
        FilledButton.icon(onPressed: () async { await Clipboard.setData(ClipboardData(text: summary)); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Doctor Summary copied.'))); }, icon: const Icon(Icons.copy_rounded), label: const Text('Copy Summary')),
        PremiumCard(child: SelectableText(summary)),
      ]),
    );
  }
}

class PrivacyVaultScreen extends StatefulWidget {
  const PrivacyVaultScreen({super.key, required this.repository});
  final CycleRepository repository;

  @override
  State<PrivacyVaultScreen> createState() => _PrivacyVaultScreenState();
}

class _PrivacyVaultScreenState extends State<PrivacyVaultScreen> {
  final pin = TextEditingController();

  void _snack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message), duration: const Duration(seconds: 2)));
  }

  @override
  Widget build(BuildContext context) {
    final data = widget.repository.data;
    return Scaffold(
      appBar: AppBar(title: const Text('Privacy Vault')),
      body: ScreenPadding(children: [
        PremiumCard(hero: true, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.lock_rounded, color: AppTheme.plum),
            const SizedBox(width: 10),
            Expanded(child: Text('Local privacy controls', style: Theme.of(context).textTheme.titleLarge)),
          ]),
          const SizedBox(height: 8),
          const Text('Your data stays on this device unless you choose to copy, export, or share it. Avenelle does not use cycle data for ad targeting.'),
        ])),
        PremiumCard(child: SwitchListTile(
          value: data.privateNotifications,
          title: const Text('Private notifications'),
          subtitle: Text(data.privateNotifications ? 'Avenelle reminder ready.' : 'Detailed reminders are enabled.'),
          onChanged: (v) async { await widget.repository.setPrivacy(privateNotifications: v); if (mounted) setState(() {}); _snack('Notification privacy saved.'); },
        )),
        PremiumCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Text('App Lock', style: Theme.of(context).textTheme.titleLarge), const Spacer(), PremiumPill(label: data.appLockEnabled ? 'Enabled' : 'Off', icon: data.appLockEnabled ? Icons.lock_rounded : Icons.lock_open_rounded, soft: data.appLockEnabled)]),
          const SizedBox(height: 12),
          TextField(controller: pin, keyboardType: TextInputType.number, obscureText: true, decoration: const InputDecoration(labelText: 'Set PIN')),
          const SizedBox(height: 10),
          FilledButton(onPressed: () async { if (pin.text.trim().isEmpty) { _snack('Enter a PIN first.'); return; } await widget.repository.setPrivacy(appLockEnabled: true, pinCode: pin.text.trim()); if (mounted) setState(() {}); _snack('PIN Lock enabled.'); }, child: const Text('Enable PIN Lock')),
          OutlinedButton(onPressed: () async { await widget.repository.setPrivacy(appLockEnabled: false); if (mounted) setState(() {}); _snack('App Lock disabled.'); }, child: const Text('Disable App Lock')),
        ])),
        PremiumCard(child: const Text('Export warning\nExported or copied summaries may be visible outside Avenelle depending on where you save or share them.')),
        FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DoctorSummaryScreen(repository: widget.repository))), icon: const Icon(Icons.copy_rounded), label: const Text('Export / Copy Doctor Summary')),
        OutlinedButton(
          onPressed: () async {
            final confirm = await showDialog<bool>(context: context, builder: (_) => AlertDialog(title: const Text('Delete all Avenelle data?'), content: const Text('This will remove your period logs, flow logs, symptoms, moods, prediction feedback, and privacy settings from this device. This cannot be undone.'), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete All Data'))]));
            if (confirm == true) { await widget.repository.deleteAllData(); if (context.mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('All local data deleted.'))); Navigator.popUntil(context, (r) => r.isFirst); } }
          },
          child: const Text('Delete All Data'),
        ),
      ]),
    );
  }
}

class ScreenPadding extends StatelessWidget {
  const ScreenPadding({super.key, required this.children});
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.fromLTRB(20, 18, 20, 32), children: children);
  }
}
