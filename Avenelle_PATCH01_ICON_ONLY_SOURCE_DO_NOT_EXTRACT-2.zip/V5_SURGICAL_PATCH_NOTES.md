# Avenelle V5 Surgical Patch Notes

Mission: preserve the working Avenelle source and patch only the V5 build/presentation gap.

Applied:
- Premium plum/cream launcher icon resources added under `v5_android_icon_patch/res`.
- README clarified as V5 surgical patch source.
- No app feature expansion.
- No tracking logic changes.
- No Guardian/Delilah/internal UI wording.

Important:
The matching GitHub workflow must copy `v5_android_icon_patch/res` into `android/app/src/main/res` after `flutter create --platforms=android .`, because that Android shell rebuild deletes any Android icons that were previously present.
