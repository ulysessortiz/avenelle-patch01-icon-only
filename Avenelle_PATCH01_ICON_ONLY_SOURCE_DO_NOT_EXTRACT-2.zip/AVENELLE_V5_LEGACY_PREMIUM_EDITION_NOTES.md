# Avenelle V5.0 Legacy Premium Edition

Protected foundation preserved from the working V4 build.

## Focus
- Premium app mark/icon direction inside the app UI.
- Public-facing cleanup: no internal version labels, prototype language, or launch-candidate badge in the live UI.
- Editable cycle history with include/exclude controls for unusual cycles.
- TrueWindow explanation preserved and made more trustworthy.
- Pattern Timeline added for before/during/after cycle understanding.
- Doctor Summary Pro includes excluded unusual cycles when present.
- Privacy Vault Pro uses public trust wording only.

## Guardrails
No new tabs, AI companion, social/community, partner mode, pregnancy mode, diagnosis engine, treatment claims, or medical certainty.
